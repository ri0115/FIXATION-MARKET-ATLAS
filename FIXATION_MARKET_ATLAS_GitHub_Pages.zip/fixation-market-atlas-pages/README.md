# FIXATION MARKET ATLAS

Offline, single-file interactive dashboard of publicly available aggregated Japanese health insurance claims and regional demographics.

## Deployment

GitHub Pages: Settings → Pages → Deploy from a branch → main → /(root).

## Notes

- Insurance claim counts are not product shipments.
- Market size is an illustrative estimate based on assumed unit prices.
- Aggregated regional data only; no patient-level data included.
